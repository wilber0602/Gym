from django.contrib import admin
from .models import Rol

admin.site.register(Rol)


# Register your models here.
